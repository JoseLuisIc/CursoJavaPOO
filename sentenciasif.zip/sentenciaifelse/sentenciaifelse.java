/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sentenciaifelse;

import javax.swing.JOptionPane;

/**
 *
 * @author joseluis.caamal
 * @deprecated Programa para saber si eres mayor de edad.
 */
public class sentenciaifelse {
    
    public static void main(String[] args) {
        
        String input = JOptionPane.showInputDialog("Ingresa tu edad");
        int edadActual = Integer.parseInt(input);
        
        if(edadActual>=18){ //Verdadero
            JOptionPane.showMessageDialog(null, "Eres mayor de edad.");
        }
        else{ //falso
            JOptionPane.showMessageDialog(null, "No eres mayor de edad.");
        }
    }
    
    
}
