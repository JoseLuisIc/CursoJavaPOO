/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sentenciaifelse;

import javax.swing.JOptionPane;

/**
 *
 * @author joseluis.caamal
 */
public class sentenciaandidad {
    
    public static void main(String[] args) {
       //Declaramos las variables a comparar
       int edadPer1 = 0; 
       int edadPer2 = 0;
       int edadPer3 = 0;
       //obtenemos información del usuario
       String edadP1 = JOptionPane.showInputDialog("Edad Persona Uno");
       String edadP2 = JOptionPane.showInputDialog("Edad Persona Dos");
       String edadP3 = JOptionPane.showInputDialog("Edad Persona Tres");
       //Convertimos la información del usuario de cadena a entero, para comparar.
       edadPer1 = Integer.parseInt(edadP1);
       edadPer2 = Integer.parseInt(edadP2);
       edadPer3 = Integer.parseInt(edadP3);
       
       //If anidados, o sentencias if anidadas
       if(edadPer1>=edadPer2){
           
           if(edadPer1>=edadPer3){
               JOptionPane.showMessageDialog(null, "La personaUno es la mayor");
           }
           else{
               if(edadPer2>=edadPer3){
                }
                else{
                    JOptionPane.showMessageDialog(null, "La personaTres es la mayor");
                }
           }
           
       }
       else{
           if(edadPer1>=edadPer3){
           
           }
           else{
               JOptionPane.showMessageDialog(null, "La personaUno es la menor");
           }
       }
        
    }
    
}
