/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package condicional;

import javax.swing.JOptionPane;

/**
 *
 * @author joseluis.caamal
 */
public class funcioncondicional {
    public static void main(String[] args) {
        
        String input = JOptionPane.showInputDialog("Ingresa tu edad");
        int edadActual = Integer.parseInt(input);
        
//        if(edadActual>=18){ //Verdadero
//            JOptionPane.showMessageDialog(null, "Eres mayor de edad.");
//        }
//        else{ //falso
//            JOptionPane.showMessageDialog(null, "No eres mayor de edad.");
//        }
            
          String respuesta = (edadActual>=18)?"Eres mayor de edad.":"No eres mayor de edad.";
          
          JOptionPane.showMessageDialog(null, respuesta);
        
    }
}
